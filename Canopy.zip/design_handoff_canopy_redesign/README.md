# Handoff: Canopy — Visual Redesign (“Clairière” direction)

## Overview
This package refreshes the visual layer of **Canopy** (the Notion-style app at
`audegrr/canopy`, Next.js + TipTap). It keeps the existing information
architecture and component structure but introduces a cleaner, calmer, more
editorial look with a light “canopy / forest” identity.

The chosen direction is **Clairière**: crisp white canvas, a single measured
forest-green accent, editorial serif headings (Newsreader) over a clean
sans-serif body (Hanken Grotesk). Two alternate directions (Canopée, Sous-bois)
are included in the same HTML behind a top switcher **for reference only** — ship
Clairière unless told otherwise.

## About the Design Files
The files in this bundle are **design references created in HTML/CSS** — a
prototype showing the intended look and behavior. They are **not** production
code to drop in. The task is to **recreate this look inside the existing Canopy
codebase** (React / Next.js, the app’s current components such as `AppShell.tsx`,
`CommandPalette.tsx`, `DatabaseBlock.tsx`, etc.), using its established patterns,
TipTap setup and styling approach (CSS variables in `app/globals.css`).

The HTML prototype hard-codes one page of real sample content (the “Questions”
note) only to make the mock feel concrete. Do not import that content — wire the
styling to the real data.

## Fidelity
**High-fidelity.** Colors, typography, spacing, radii and interaction states are
intended to be used as-is. Recreate pixel-for-pixel using the codebase’s existing
component structure.

## What changed vs. the current app (review-driven)
These reflect explicit decisions from the design review — please preserve them:

1. **Accent color** moved from Notion blue (`#2383e2`) to **forest green `#2f6b4f`**.
2. **Headings** now use an **editorial serif** (Newsreader); body stays sans-serif.
3. **Sidebar hover no longer shifts page titles.** Row action icons
   (favorite / add / more) are **absolutely positioned** over the right edge with
   a short gradient fade, so the page label keeps full width and never reflows on
   hover. (Do NOT implement row actions as in-flow flex children that consume
   width on hover — that caused the “names jump” problem.)
4. **Section label “Pages”** uses the **body font** (11.5px / 600, sentence case),
   not a monospace all-caps treatment.
5. **Workspace icon stays an emoji** (🔍 for “Job Search”), matching the original.
6. **Zoom control**: minus / value / plus with **vertical divider lines** between
   the value and each button; value uses the **body font** (not monospace):
   `−  | 100% |  +`.
7. **Favorite from the sidebar**: hovering any page row reveals a **star** that
   toggles favorite state (fills green when active). The same favorite star also
   exists in the top-right page toolbar.
8. **Top-right page toolbar** consolidated from the old multi-color icon row into
   a single monochrome, line-icon set (see “Page toolbar” below). The colorful
   icons were intentionally unified for the minimal look — if you want color back,
   that’s a deliberate future choice, not a regression.
9. **App UI chrome is in English** (the app is for an English-speaking user).
   User note *content* can be any language.
10. **Logo / favicon**: the existing tree mark (`public/canopy_logo@2x.png`,
    `public/canopy_favicon_no_bg.ico`) is reused as-is, shown without any box/tile
    behind it in the sidebar.

## Screens / Views
Single screen: the **document editor** with a left **sidebar**, a **top bar**, and
a centered **page** column.

### Sidebar (width 256px, fixed)
- Background `var(--side-bg)` `#fafaf8`, right border `#eeede9`.
- **Header**: tree logo (30×30, no tile) + wordmark “Canopy” in serif, 18px/600.
- **Workspace card**: 26×26 rounded tile holding an **emoji** (🔍), name “Job
  Search” (13px/600), sub “Workspace” (11px), chevron at right. Hover bg
  `rgba(40,38,32,.05)`.
- **Quick actions**: “New page” (doc icon), “New database” (db icon), 13.5px,
  muted color, hover lightens.
- **Section label**: “Pages” — body font, 11.5px/600, color `var(--side-text-2)`.
- **Tree rows** (`.nav`): 5px/8px padding, radius 7px. A row has: optional twist
  chevron (rotates 90° when open), a page glyph, the label (truncates with
  ellipsis), and **hover-only row actions** (star/add/more) absolutely pinned
  right over a `linear-gradient(90deg, transparent, var(--side-fade) 38%)` fade.
  Active row: bg `rgba(40,38,32,.075)`, label 600, plus a 3px green accent bar on
  the left edge (`::before`, `var(--side-accent)`).
- **Sub-tree**: indented `margin-left:24px`, `padding-left:6px`, with a 1.5px left
  guide border `var(--side-border)`. (Indentation must be clearly visible —
  matches the original.)
- **Footer**: user row — 30px gradient avatar (green), name 13px/600, email 11px
  muted, power/logout icon at right.

### Top bar (height 52px)
- Sticky, `var(--topbar-bg)` translucent white + `backdrop-filter: blur(8px)`,
  bottom border `var(--border)`.
- Left: collapse-sidebar button (hamburger) that toggles the sidebar with a
  `margin-left:-257px` slide (transition `.26s cubic-bezier(.4,0,.2,1)`).
- **Breadcrumbs**: parent “Fortum — Specialist” / current “Questions”, 13.5px,
  chips with 5px radius, hover bg `var(--hover)`.
- Right cluster:
  - **Zoom**: bordered pill, `−  | 100% |  +`, value in body font, dividers are
    `border-left/right` on the value element.
  - **Search pill**: search icon + “Search” + `⌘K` kbd chip; hover strengthens
    border + bg.
  - **Notifications** bell icon button.

### Page toolbar (sticky, right-aligned, above the title)
Order, left→right — all monochrome line icons except the text button:
- `Edited just now` — muted timestamp text (`var(--text-3)`, 12.5px).
- **Share** — *text* button (this is the primary action, like Notion).
- **Ask AI** — sparkle icon. This is the AI writing assistant (“Assistant” in the
  old mock). Tooltip: “Ask AI — writing assistant”.
- **Comments** — comment icon.
- **Favorite** — star icon, `data-fav`, toggles filled green; tooltip flips
  between “Add to favorites” / “Remove from favorites”.
- **Page history** — clock icon.
- **More options** — three-dots icon (host “copy link”, export, move, delete, etc.
  in its menu).

### Page (content column)
- `max-width: 720px`, centered, `padding: 58px 28px 200px`.
- **Cover row**: appears on page hover only — “Add icon” (smile) and “Add cover”
  (image), muted, hover chip.
- **Title**: serif (Newsreader), 2.5rem / 600, letter-spacing −0.018em,
  line-height 1.1, `text-wrap: balance`, color `var(--text)`.
- **Blocks**: each `.block` exposes left **handles** (`+` add, grip drag) on hover,
  pinned at `left:-46px`, fade in.
- **Heading block** (`.h-block`): serif, 1.55rem/600.
- **Paragraph block** (`.p-block`): 16px, line-height 1.72. `.dim` variant uses
  `var(--text-2)`.
- **Inline `>` in note text is plain text** — NOT highlighted/chipped. (Earlier
  version wrapped `>` in a green tag; that was removed.)
- **Callout**: green-tinted surface `var(--accent-soft)`, 1px green-alpha border,
  11px radius, leading sparkle icon in accent color.

## Interactions & Behavior
- **Direction switcher** (top, dark bar): swaps `data-dir` on `.app`; persisted to
  `localStorage('canopy_dir')`. **This switcher is an exploration aid — remove it
  in production** and ship the Clairière token set as the app theme.
- **Sidebar collapse**: toggles `.collapsed` on `.app` → sidebar slides out.
- **Tree expand/collapse**: clicking the twist toggles `.open` on the `.nav`,
  revealing the `.subtree`.
- **Page switching**: clicking a tree row swaps the visible `.page[data-content]`
  and updates the current breadcrumb.
- **Favorite toggle**: any `[data-fav]` element toggles `.faved` (star fills with
  accent); top-bar button also flips its tooltip.
- Row actions and cover row are **hover-revealed** (opacity), never layout-shifting.
- Transitions: hovers `.12s`, sidebar slide `.26s`, twist rotate `.16s`.

## Design Tokens (Clairière — ship these)
```
/* surfaces & text */
--bg:            #ffffff
--text:          #2a2824
--text-2:        #6d6b64
--text-3:        #a9a79f
--border:        #ecebe8
--border-strong: #e0dfdb
--hover:         #f4f3f1

/* accent (forest green) */
--accent:        #2f6b4f
--accent-soft:   #eef4f0

/* sidebar */
--side-bg:       #fafaf8
--side-text:     #45433d
--side-text-2:   #8d8b82
--side-hover:    rgba(40,38,32,.05)
--side-active:   rgba(40,38,32,.075)
--side-border:   #eeede9
--side-fade:     #f2f1ee   /* solid stand-in for hovered row bg, used in the row-action gradient */
--side-accent:   #2f6b4f

/* radii */
--radius: 7px;  --radius-sm: 5px;  --radius-lg: 11px;

/* type */
--font-head: 'Newsreader', Georgia, serif;       /* titles & headings */
--font-body: 'Hanken Grotesk', -apple-system, sans-serif;  /* body & UI */
--font-mono: 'JetBrains Mono', ui-monospace, monospace;    /* kbd chips only */
--title-size: 2.5rem;  --title-weight: 600;  --title-spacing: -0.018em;
--content-w: 720px;
```
Type scale: title 2.5rem/600, heading 1.55rem/600, body 16px/1.72, UI 13–13.5px,
small/meta 11–12.5px.

### Alternate directions (reference only — not for shipping)
- **Canopée**: paper bg `#fdfbf7`, sage accent `#4d6b50`, Spectral headings,
  IBM Plex Sans body.
- **Sous-bois**: white canvas, deep-green sidebar rail `#1c3a2d` with light text,
  accent `#2c6e49`, Source Serif 4 headings.
Full token sets for these live in `canopy-redesign.css` under
`.app[data-dir="canopee"]` and `.app[data-dir="sousbois"]`.

## Fonts
Google Fonts. For the shipped Clairière theme you only need:
`Newsreader` (400–700) and `Hanken Grotesk` (400–700). `JetBrains Mono` is used
only for the `⌘K` chip. (Canopée/Sous-bois additionally use Spectral, IBM Plex
Sans, Source Serif 4 — skip unless you ship those.)

## Assets
- `public/canopy_logo@2x.png` — existing Canopy tree logo (reused as-is).
- `public/canopy_favicon_no_bg.ico` — transparent-bg favicon (reused as-is).
Both already exist in the repo at the same paths; no new art required. Icons in
the mock are inline SVGs (Lucide-style 1.7px stroke) — match them to whatever icon
library the codebase already uses.

## Files
- `Canopy Redesign.html` — the prototype (open in a browser to interact). Contains
  inline SVG icon defs, the three direction themes, and all interaction JS.
- `canopy-redesign.css` — all styles and design tokens (the source of truth for
  values; `:root` = Clairière).
- `public/` — logo + favicon.

## Implementation notes for the Canopy codebase
- Map the Clairière `:root` tokens into `app/globals.css` (replace the current
  blue accent and any Notion-blue references).
- Keep TipTap/editor behavior; this is a **styling + small-interaction** pass.
- The **row-action absolute-positioning** fix and the **sidebar sub-page
  indentation** are the two structural details most likely to be missed — verify
  both after implementing.
- Remove the exploration-only **direction switcher** bar and any `data-dir`
  plumbing when integrating.
